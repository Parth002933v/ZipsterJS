import {Command} from "commander";
import * as process from "node:process";
import {commands} from "./commands";
import figlet from "figlet"
import chalk from "chalk";

const program = new Command()

program
    .name(chalk.cyanBright(figlet.textSync("zipsterjs")))
    .description(chalk.bold(chalk.italic("ZipsterJS a cli tool to compress and archive files")))
    .version("1.0.0")
    .action(()=>{
        console.log(chalk.greenBright("Compress the project directory to compress"));
    })

commands.forEach((c) => {
    program.addCommand(c)
})

program.parse(process.argv)
