import compress from "./compress.js";
import {decompress} from "./decompress";

export const commands = [compress, decompress]